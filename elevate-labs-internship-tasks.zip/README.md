# Java Console Calculator

Simple Java console calculator for internship Task 1.

## How to Run
Navigate to src/main/java and compile:
```
javac Calculator.java
java Calculator
```
